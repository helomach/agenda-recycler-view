package com.example.recyclerview.model;

public class Compromisso {
    private String titulo;
    private String data;
    private String local;
    private String horario;

    public Compromisso(String titulo, String data, String local, String horario) {
        this.titulo = titulo;
        this.data = data;
        this.local = local;
        this.horario = horario;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getData() {
        return data;
    }

    public String getLocal() {
        return local;
    }

    public String getHorario() {
        return horario;
    }
}