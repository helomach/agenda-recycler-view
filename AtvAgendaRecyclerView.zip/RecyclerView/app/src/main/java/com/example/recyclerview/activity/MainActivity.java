package com.example.recyclerview.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerview.R;
import com.example.recyclerview.adapter.Adapter;
import com.example.recyclerview.model.Compromisso;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Adapter adapter;
    private List<Compromisso> listaCompromissos;

    private EditText editTextTitulo;
    private EditText editTextData;
    private EditText editTextHorario;
    private EditText editTextLocal;
    private Button btnAdicionar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando a lista de compromissos
        listaCompromissos = new ArrayList<>();

        // Configurando o RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        // Configurando o Adapter
        adapter = new Adapter(listaCompromissos);
        recyclerView.setAdapter(adapter);

        // Inicializando os campos de entrada e o botão
        editTextTitulo = findViewById(R.id.editTextTitulo);
        editTextData = findViewById(R.id.editTextData);
        editTextHorario = findViewById(R.id.editTextHorario);
        editTextLocal = findViewById(R.id.editTextLocal);
        btnAdicionar = findViewById(R.id.btnAdicionar);

        // Configurando o clique do botão para adicionar um novo compromisso
        btnAdicionar.setOnClickListener(v -> adicionarCompromisso());

        // Configurando o RecyclerItemClickListener para clicar em itens
        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // Verificando se a posição é válida
                        if (position >= 0 && position < listaCompromissos.size()) {
                            // Obtendo o compromisso clicado e mostrando um Toast com o local
                            Compromisso compromisso = listaCompromissos.get(position);
                            Toast.makeText(MainActivity.this, "Local: " + compromisso.getLocal(), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Erro ao obter o compromisso", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {
                        // Implementação opcional para clique longo, se necessário
                    }
                })
        );
    }

    private void adicionarCompromisso() {
        // Obtendo os valores dos campos de entrada
        String titulo = editTextTitulo.getText().toString().trim();
        String data = editTextData.getText().toString().trim();
        String horario = editTextHorario.getText().toString().trim();
        String local = editTextLocal.getText().toString().trim();

        // Validando os campos
        if (titulo.isEmpty() || data.isEmpty() || horario.isEmpty() || local.isEmpty()) {
            Toast.makeText(this, "Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Criando e adicionando um novo compromisso à lista
        Compromisso compromisso = new Compromisso(titulo, data, local, horario);
        listaCompromissos.add(compromisso);
        adapter.notifyDataSetChanged();

        // Limpando os campos
        editTextTitulo.setText("");
        editTextData.setText("");
        editTextHorario.setText("");
        editTextLocal.setText("");
    }
}
